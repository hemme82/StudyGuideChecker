package com.base64.d;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class KnownFalsePositives {

    public static final String[] SET_VALUES = new String[]{
            "https://content.infinitecampus.com/sis/latest/simulation/send-a-behavior-message-sc-01-28-01",
            "https://content.infinitecampus.com/sis/latest/simulation/schedule-attendance-message-sc-01-24-02",
            "https://content.infinitecampus.com/sis/latest/simulation/schedule-a-behavior-message-sc-01-27-02",
            "https://content.infinitecampus.com/sis/latest/simulation/create-a-behavior-message-template-sc-01-27-01",
            "https://content.infinitecampus.com/sis/latest/simulation/view-individual-student-attendance"
    };

    public static final Set<String> WHITE_LIST = new HashSet<String>(Arrays.asList(SET_VALUES));



//    public KnownFalsePositives(Set<String> knownFalsePositives) {
//        this.knownFalsePositives = knownFalsePositives;
//    }
//
//    public Set<String> getKnownFalsePositives() {
//        return knownFalsePositives;
//    }
//
//    public void setKnownFalsePositives(Set<String> knownFalsePositives) {
//        this.knownFalsePositives = knownFalsePositives;
//    }
}
